import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css';

const MainComponent = () => {
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [previewSrc, setPreviewSrc] = useState('');
  const [isLanguageChecked, setIsLanguageChecked] = useState(false);
  const [inputText, setInputText] = useState('');

  const url = "http://127.0.0.1:5000";

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewSrc(e.target.result);
        setFileName(file.name);
        setFileSize((file.size / 1024).toFixed(2) + ' KB');
      };
      reader.readAsDataURL(file);
      setFile(file);
    }
  };

  const handleBrowseClick = () => {
    document.getElementById('file-upload').click();
  };

  const handleCheckboxChange = (event) => {
    if (event.target.id === 'translate-spanish') {
      setIsLanguageChecked(event.target.checked);
    }
  };

  const handleTextChange = (event) => {
    setInputText(event.target.value);
  };

  const handleUpload = () => {
    const formData = new FormData();
    if (file) {
      formData.append('file', file);
    }
    formData.append('text', inputText);
  
    const selectedLanguages = Array.from(document.querySelectorAll('#language-options option:checked')).map(option => option.value);
    formData.append('languages', JSON.stringify(selectedLanguages));
  
    const selectedAgeGroup = document.getElementById('age-group').value;
    formData.append('ageGroup', selectedAgeGroup);
  
    fetch(url + '/upload', {
      method: 'POST',
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Upload failed.');
        }
      })
      .then((data) => {
        if (data.filename || data.text_input) {
          const query = data.filename ? `?filename=${encodeURIComponent(data.filename)}` : `?text_input=${encodeURIComponent(data.text_input)}`;
          return fetch(`${url}/recreation_result${query}`);
        } else {
          throw new Error('Filename or text not returned.');
        }
      })
      .then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Fetching recreation result failed.');
        }
      })
      .then((data) => {
        if (data.file_url && data.o1 && data.o2 && data.o3) {
          navigate('/recreation_result', {
            state: {
              fileUrl: data.file_url,
              o1: data.o1,
              o2: data.o2,
              o3: data.o3,
            },
          });
        } else {
          console.error('Required data not returned.');
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };
  

  return (
    <div className="main-container">
      <video className="background-video" autoPlay loop muted>
        <source src="/backgroundVideo.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="content-overlay">
        <h1 className="app-title">Marketing Material Compliance - Content Creator</h1>
        <div className="upload-box">
          <div className="upload-header">
            <img src="/upload.png" alt="Upload Icon" className="upload-icon-image" />
            <h2>Upload Image or Enter Text</h2>
          </div>
          <input
            type="file"
            id="file-upload"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />
          <div className="button-group">
            <button id="browse-btn" onClick={handleBrowseClick} className="glass-button">
              Browse Image
            </button>
            {!file && (
              <button id="upload-btn" onClick={handleUpload} className="glass-button">
                Upload
              </button>
            )}
          </div>
          <input
            type="text"
            id="text-input"
            placeholder="Enter your text here..."
            className="text-input"
            onChange={handleTextChange}
          />
          {file && (
            <>
              <div id="preview">
                <div className="preview-container">
                  <img
                    id="preview-image"
                    src={previewSrc}
                    alt="Image Preview"
                    style={{ maxWidth: '250px', maxHeight: '250px' }}
                  />
                  <div className="file-info-overlay">
                    <div>Name: {fileName}</div>
                    <div>Size: {fileSize}</div>
                  </div>
                </div>
                <div className="checkbox-group">
                  <label>
                    <input type="checkbox" id="email-content" /> Email Content
                  </label>
                  <label>
                    <input type="checkbox" id="social-media-post" /> Social Media Post
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      id="translate-spanish"
                      onChange={handleCheckboxChange}
                    /> Language Translation
                  </label>
                </div>
                <div className="Dropdowns">
                  <div className="dropdown-group">
                    <select id="age-group" className="dropdown">
                      <option value="">Select Age Group</option>
                      <option value="15-20 (Male)">15-20 (Male)</option>
                      <option value="20-40 (Male)">20-40 (Male)</option>
                      <option value="40-60 (Male)">40-60 (Male)</option>
                      <option value="15-20 (Female)">15-20 (Female)</option>
                      <option value="20-40 (Female)">20-40 (Female)</option>
                      <option value="40-60 (Female)">40-60 (Female)</option>
                    </select>
                  </div>
                  {isLanguageChecked && (
                    <div className="dropdown-group">
                      <select id="language-options" className="dropdown" multiple style={{ marginLeft: '-10px' }}>
                        <option value="English">English</option>
                        <option value="Spanish">Spanish</option>
                        <option value="French">French</option>
                        <option value="German">German</option>
                        <option value="Chinese">Chinese</option>
                        <option value="Japanese">Japanese</option>
                        <option value="Hindi">Hindi</option>
                      </select>
                    </div>
                  )}
                </div>
              </div>
              <button id="upload-btn" onClick={handleUpload} className="glass-button">
                Upload
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainComponent;
