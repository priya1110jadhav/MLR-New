from groq import Groq

import ast


def final_list(llm_answer):
    client = Groq(api_key="")
    completion = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=[
            {
                "role": "system",
                "content": "Instructions->\n                    \"Products established name\": \"This attribute should contain any name. This attribute should not have an empty value.\",\n                    \"Quantitative composition\": \"This attribute should contain contain any numerical value. (e.g., 75 mg, 45 mg).This attribute should not have an empty value. \",\n                    \"Side effects\": \"This attribute should contain any side effect name. This attribute should not have an empty value.\",\n                    \"Warning\": \"This attribute should contain any type of warning. This attribute should not have an empty value.\",\n                    \"Effectiveness\": \"This attribute should contain an effectiveness of the product. This attribute should not have an empty value.\",\n                    \"Adverse reactions\": \"This attribute should contain any type of adverse reactions. This attribute should not have an empty value.\",\n                    \"Statement encouraging consumers to report negative side effects to FDA\": \"This attribute should contain any statement encouraging consumers to report negative side effects to FDA. This attribute should not have an empty value.\",\n                    \"Language and Readability\": (\n                        \"Use consumer-friendly language in all consumer-directed materials. Avoid technical language, scientific terms, and medical jargon. Use engaging language, such as: 'do not use if you have...' or 'who should not use...' rather than 'contraindications', 'what is [drug name]' rather than 'indication', 'drowsiness' not 'somnolence', 'fainting' not 'syncope'. Use double spacing between paragraphs and indentations to improve readability. Present information in a readable format with appropriate font size and style. Use text boxes with headings and symbols to highlight information.\"\n                    )\n        data=Input of the user (Text to be evaluated.)\n        Both the Instructions and data has same key names with different corresponding values.\n        Compare and Validate: Compare each value in the data dictionary against the value specified in the Instructions dictionary for each corresponding key.\n        Filter and Return Matching keys: In output should only return those keys where the value in data meets the value criteria specified in Instructions. Format of output should be: [List of keys]. Other that this list do not print any other thing. Do not give any code.\n        "
            },
            # {
            #     "role": "user",
            #     "content": "\"\"\"Product’s established name: Not there.\n\nQuantitative composition: Blank.\n\nSide effects: Not explicitly listed in the provided text.\n\nWarning: The warning section highlights the importance of informing healthcare providers about pregnancy or any medications taken, as these may affect the risk of heart disease. It also cautions against simple blood tests for cholesterol levels if the patient has unexplained confusion or tells their doctor right away as these may indicate a rare but potentially life-threatening condition called TTP, which can be reported to the FDA.\n\nEffectiveness: The text suggests that VOTREA reduces bad cholesterol for people with several common risk factors for heart disease, starting from an average bad cholesterol of 160 mg/dl. With VOTREA, 65 out of 100 people (65%) lowered their bad cholesterol to normal levels versus 2 out of 100 people (2%) with no treatment.\n\nAdverse reactions: The text mentions that VOTREA can increase the risk for heart disease, including high LDL (bad cholesterol), low HDL (good cholesterol), family history of heart disease, smoking, age, and obesity.\n\nA statement encouraging consumers to report negative side effects to FDA: Yes, there is a statement at the bottom of the image that encourages consumers to report negative side effects of prescription drugs to the FDA.\n\nLanguage & Readability: The text is written in clear, easily understandable English, with a mix of bold and regular fonts to emphasize important information.\"\"\""
            # },
            {
                "role": "user",
                "content": f"""{str(llm_answer)}""",
            },
        ],
        temperature=0,
        max_tokens=1024,
        top_p=1,
        stream=True,
        stop=None,
    )
    ans= ""
    for chunk in completion:
        #print(chunk.choices[0].delta.content or "", end="")
        a=str(chunk.choices[0].delta.content)
        if(a!="None"):
            ans+=str(chunk.choices[0].delta.content)
        #print(type(chunk.choices[0].delta.content))
        
    print(ans)   
    print(type(ans))

    actual_list = ast.literal_eval(ans)

    # print(actual_list)
    # print(type(actual_list))

    return actual_list
