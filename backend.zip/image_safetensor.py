# test.py
import torch
from PIL import Image
from transformers import AutoModel, AutoTokenizer

model = AutoModel.from_pretrained('openbmb/MiniCPM-Llama3-V-2_5-int4', trust_remote_code=True,device_map='cuda')
tokenizer = AutoTokenizer.from_pretrained('openbmb/MiniCPM-Llama3-V-2_5-int4', trust_remote_code=True)
model.eval()

def handle_image(image,question):
    #image = Image.open(image).convert('RGB')
    #question = 'Give each and every textual content present in the image. Also describe each and every feature in the image.Give the answer in very detailed format.'
    msgs = [{'role': 'user', 'content': question}]

    res = model.chat(
        image=image,
        msgs=msgs,
        tokenizer=tokenizer,
        sampling=True,
        temperature=0.7
    )
    return res

#print(model.answer_question(enc_image, "What is present in these image? Try to collect most of the information and give the answer in very detailed format.", tokenizer))
