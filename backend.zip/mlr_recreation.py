import pandas as pd
import os
import openai
openai.api_type = "azure"
openai.api_base = "https://jnj-ls-rg.openai.azure.com/"
#openai.api_base = "https://jnj-chatbot-qna.openai.azure.com/"
openai.api_version = "2023-09-15-preview"
openai.api_key = ""


def generate_new_trial(llm_answer,language,ageGroup):
    # Extract the required fields from the row
    # Prepare the prompt for the language model
    prompt = [f"Convert this Advertising Template text{llm_answer} into proper an email format for Age Group {ageGroup}. Limit it upto 110 words maximum. Keep in mind all the medical,legal,regulatory terms will doing it.",
              f"Convert this Advertising Template text{llm_answer} into a social media post for Age Group {ageGroup}. Limit it upto 35 words maximum. Make it very precise and small. Add some spaces between lines for better look. Keep in mind all the medical,legal,regulatory terms will doing it. Make it creative by adding some symbols,emojis and hashtags. Add spaces, gaps between lines wherever needed.",
              f"Convert this Advertising Template text{llm_answer} into {language} language for Age Group {ageGroup}. Limit it upto 60 words maximum. Keep in mind all the medical,legal,regulatory terms will doing it."]
    # Generate a new clinical trial design using the OpenAI model
    final=[]
    for i in prompt:
        response = openai.Completion.create(
                engine="chatbot35",
                #engine="chatbotcliqna",
                prompt=i,
                temperature=0.7,
                max_tokens=1800,
                top_p=0.5,
                frequency_penalty=0,
                presence_penalty=0,
                best_of=1,
                stop=None)
        
        faqs = response.choices[0].text.strip()
        final.append(faqs)
    # # Extract the generated trial design from the response

    return final

# Load the data from the Excel file
# data = pd.read_excel("test.xlsx")

# Choose a row from the dataframe
# row = data.iloc[0]  # Replace 0 with the desired row index
llm_answer="""©2005 Ristolay-Yers may Quibbsay Anofisay Pharmaceuticals Partnership
At 6'4" 220 pounds,
Bob is a formidable man.
But he's no match for something
one millionth his size.
A CLOT.
Clots are the number one cause of heart attack and stroke, but you can help reduce your risk.
This is important information if you've been hospitalized with
heart-related chest pain or a certain type of heart attack.
That's because these conditions, known as Acute Coronary
Syndrome or ACS are usually caused
when blood platelets stick together and
form clots that block blood flow to your
heart. And if you've already had a clot.
you're at an increased risk for a future
heart attack or stroke.
PRIDCLO,in combination with aspirin, helps provide greater
protection against a future heart attack or stroke than aspirin alone.
PRIDOLO, taken with aspirin, plays its own role in helping reduce
your risk of heart attack and stroke.
That's because, unlike your cholesterol
and blood pressure medications.
prescription PRIDCLO works directly
to help keep blood platelets from
sticking together and forming clots.
IMPORTANT INFORMATION: If you have a stomach ulcer or other condition that causes bleeding, you shouldn't use PRIDCLO
When taking PRIDCLO alone or with some medicines including aspirin, the risk of bleeding may increase. To minimize this risk,
talk to your doctor before taking aspirin or other medicines with
PRIDCLO. Additional rare but serious side effects could occur.
Talk to your doctor today to learn more about PRIDCLO
Or visit www.pridco.com or call 1.800.903.5063.
See important product information on the following page.
ONCE-A-DAY
PridcloⓇ
(pricogrel) 75mg tablets
BECAUSE YOU'RE NO MATCH FOR A DANGEROUS CLOT.
ansolvensay
USA CLOSE June 2006 81-01 00
Are Yay Inc, a member of the assayGroup"""
#new_trial = generate_new_trial(llm_answer,language)

#print(new_trial)
