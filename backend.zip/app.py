from flask import Flask, render_template, request, redirect, url_for, jsonify
from collections import OrderedDict
import os
import image_safetensor
from PIL import Image
import mlr_recreation
import json
import groq_mlr
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes



UPLOAD_FOLDER = 'static/uploads' 
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    # if 'file' not in request.files:
    #     return jsonify({"error": "No file part"}), 400
    
    file = request.files.get('file')
    text_input = request.form.get('text')
    print(text_input)

    # if file.filename == '':
    #     return jsonify({"error": "No selected file"}), 400

    global language
    global ageGroup
    
    if file:
        filename = file.filename
        print(f"----------------languages-------------------------------------------",filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        #file.save(os.path.join('mlr2.0/public/images', filename))


        languages = request.form.get('languages')
        if languages:
            languages = json.loads(languages) 
             # Parse the JSON string to a list
            language=languages[0] 
            print(f"----------------languages-------------------------------------------",language)

        ageGroup = request.form.get('ageGroup')
        print(f"----------------languages-------------------------------------------",ageGroup)
    

        return jsonify({"filename": filename}), 200
    elif text_input:

        languages = request.form.get('languages')
        if languages:
            languages = json.loads(languages) 
             # Parse the JSON string to a list
            language=languages[0] 
            print(f"----------------languages-------------------------------------------",language)

        ageGroup = request.form.get('ageGroup')
        return jsonify({"text_input": text_input}), 200
    

@app.route('/result')
def result():
    filename = request.args.get('filename', None)
    print(filename)
    try: 
        if filename:
            global file_url
            file_url = url_for('static', filename='uploads/' + filename)
            print(file_url)
            url='static/uploads/'+filename
            img = Image.open(url).convert('RGB')

            # question = """Capture each and every textual content + features present in the image. And print the response in the following format (Note:- Please print each following attribute in a linewise format):

            #       -Product’s established name
            #       -quantitative composition
            #       -side effects
            #       -Warning:(side-effects/contraindications/precautions/cautions/special considerations,important notes).
            #       -effectiveness
            #       -Adverse reactions
            #       -a statement encouraging consumers to report negative side effects to FDA
            #       -Language & Readability


            #       Make use of this attributes and fill all the available data in this attributes.
 
            #      .Give the answer in very detailed format."""

            question = """Capture all the information in the image and fill in the following attributes.Do not change the attribute names keep the as it is.(Note:- Please print each following attribute in a linewise format):

                  -Products established name
                  -Quantitative composition 
                  -Side effects
                  -Warning
                  -Effectiveness
                  -Adverse reactions
                  -Statement encouraging consumers to report negative side effects to FDA
                  -Language and Readability

                  Note: Instructions regarding which content form the image should be captured in this attributes:-
                        -Products established name: In this attribute capture the established name/proprietary name/Brand name.(If any)   
                        -Quantitative Composition: In this attribute capture the Drug dose Numeric value with mg or ml volumetrics.(If any)
                        -Warning: In this attribute capture the Information that would affect a decision of Doctor or Physician or Pharmacist to prescribe or take a drug; monitoring or laboratory tests that may be needed; measures that can be taken to prevent or mitigate harm like allergies,etc.(If any)
                        -Adverse reactions: In this attribute capture any Contraindications, Special condition, drug interaction with other medicines or food or multivitamin supplements. Drug interaction with changed physiological conditions like Pregnancy, organ failure, other disease condition, etc.(If any)
                        -Statement encouraging consumers to report negative side effects to FDA: In this attribute capture any FDA website or FDA contact number or Company’s contact information or a line statement: Talk to your health care provider or pharmacist for more information.(If any)
                        -Language and Readability:In this attribute capture the overall readability, style and font of textual content in image. How cleanly the content is written in the image, etc.(If any)

                """

            # question = """
            
            # Capture all the information in the image and fill in the following attributes.(Note:- Please print each following attribute in a linewise format):

            # -What is [drug] used for?
            # -When should I not take [drug]?
            # -What Warnings should I know about [drug]?
            # -What should I tell my health care provider?
            # -What are the side effects of [drug]?
            # -What other medications might interact with [drug]?

            # """
            
            llm_answer=image_safetensor.handle_image(img,question)
            print(llm_answer)

            highlightList=groq_mlr.final_list(llm_answer)
            print(highlightList)

            wordHover = {
                    "Products established name": "This attribute should contain any name. This attribute should not have an empty value.",
                    "Quantitative composition": "This attribute should contain contain any numerical value. (e.g., 75 mg, 45 mg).This attribute should not have an empty value. ",
                    "Side effects": "This attribute should contain any side effect name. This attribute should not have an empty value.",
                    "Warning": "This attribute should contain any type of warning. This attribute should not have an empty value.",
                    "Effectiveness": "This attribute should contain an effectiveness of the product. This attribute should not have an empty value.",
                    "Adverse reactions": "This attribute should contain any type of adverse reactions. This attribute should not have an empty value.",
                    "Statement encouraging consumers to report negative side effects to FDA": "This attribute should contain any statement encouraging consumers to report negative side effects to FDA. This attribute should not have an empty value.",
                    "Language and Readability": "Use consumer-friendly language in all consumer-directed materials. Avoid technical language, scientific terms, and medical jargon. Use engaging language, such as: 'do not use if you have...' or 'who should not use...' rather than 'contraindications', 'what is [drug name]' rather than 'indication', 'drowsiness' not 'somnolence', 'fainting' not 'syncope'. Use double spacing between paragraphs and indentations to improve readability. Present information in a readable format with appropriate font size and style. Use text boxes with headings and symbols to highlight information."
                }
            
            word = ["Products established name", "Quantitative composition", "Side effects", "Warning", "Effectiveness", "Adverse reactions", "Statement encouraging consumers to report negative side effects to FDA", "Language and Readability"]
            
    #         final_table = [
    # ("Products established name", 0),
    # ("Quantitative composition", 0),
    # ("Side effects", 0),
    # ("Warning", 0),
    # ("Effectiveness", 0),
    # ("Adverse reactions", 0),
    # ("Statement encouraging consumers to report negative side effects to FDA", 0),
    # ("Language and Readability", 0),
    # ("Total Compliance", 0)
#]

            #avg = 0
            # Create a new list to store the updated values
#             updated_final_table = []

#             # Update the values based on highlightList
#             for item in final_table:
#                 if item[0] in highlightList:
#                     updated_final_table.append((item[0], 100))
#                     avg += 100
#                 else:
#                     updated_final_table.append(item)

#             avg = avg / 8

# # Update the "Total Compliance" value
#             final_table = [(name, value) if name != "Total Compliance" else (name, avg) for name, value in updated_final_table]

#             print(final_table)
            final_table = OrderedDict([
    ("Products established name", 0),
    ("Quantitative composition", 0),
    ("Side effects", 0),
    ("Warning", 0),
    ("Effectiveness", 0),
    ("Adverse reactions", 0),
    ("Statement encouraging consumers to report negative side effects to FDA", 0),
    ("Language and Readability", 0),
    ("Total Compliance", 0)
])
            avg=0
            for i in final_table:
                if i in highlightList:
                    final_table[i]=100
                    avg+=100  
            avg=(avg/8)
            final_table["Total Compliance"]=avg  
            print(final_table)  

        

            

        return jsonify({"file_url":file_url,"llm_answer":llm_answer,"highlightList":highlightList,"wordHover":wordHover,"word":word,"final_table":final_table})
        #return 'result.html', file_url=file_url,llm_answer=llm_answer,highlightList=highlightList,wordHover=wordHover,word=word,final_table=final_table)
    except Exception as e:
        print(e)
        return "No file uploaded"


@app.route('/content_recreation')
def content_recreation():
    return render_template('content_recreation.html')

@app.route('/content_review')
def content_review():
    return render_template('content_review.html')      


@app.route('/recreation_result')
def recreation_result():
    filename = request.args.get('filename', None)
    text_input=request.args.get('text_input',None)
    print(text_input)
    print(filename)
    try: 
        if filename:
            global file_url
            file_url = url_for('static', filename='uploads/' + filename)
            print(file_url)
            url='static/uploads/'+filename
            img = Image.open(url).convert('RGB')
            
            question1="Capture each and every texual information present in the image. Give the answer in very detailed format."

            # q1="Convert this Advertising Template image into proper an email format. Keep in mind all the medical,legal,regulatory terms will doing it."
            # q2="Convert this Advertising Template image into a social media post. Keep in mind all the medical,legal,regulatory terms will doing it. Make it creative by adding some symbols and hashtags where ever needed."
            # q3="Convert this Advertising Template image into spanish language. Keep in mind all the medical,legal,regulatory terms will doing it."

            llm_answer1=image_safetensor.handle_image(img,question1)
            print(llm_answer1)
            final=mlr_recreation.generate_new_trial(llm_answer1,language,ageGroup)

            print(final)
            o1=final[0]
            o2=final[1]
            o3=final[2]

            # o1=image_safetensor.handle_image(img,q1)
            # o2=image_safetensor.handle_image(img,q2)
            # o3=image_safetensor.handle_image(img,q3)

            #return render_template('recreation_result.html', file_url=file_url,o1=o1,o2=o2,o3=o3)
            return jsonify({"file_url":file_url,"o1":o1,"o2":o2,"o3":o3})
        
    
        elif text_input:
            final=mlr_recreation.generate_new_trial(text_input,language,ageGroup)

            print(final)
            o1=final[0]
            o2=final[1]
            o3=final[2]

            # o1=image_safetensor.handle_image(img,q1)
            # o2=image_safetensor.handle_image(img,q2)
            # o3=image_safetensor.handle_image(img,q3)

            #return render_template('recreation_result.html', o1=o1,o2=o2,o3=o3)
            return jsonify({"o1":o1,"o2":o2,"o3":o3})

    except Exception as e:
        print(e)
        return "No file/text uploaded"

if __name__ == '__main__':
    app.run(debug=True)
